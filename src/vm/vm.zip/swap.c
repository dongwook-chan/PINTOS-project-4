#include "vm/swap.h"

#define SWAP_FREE 0
#define SWAP_IN_USE 1

struct bitmap* swap_map;
struct block* swap_block;
struct lock swap_lock;

void
swap_init (void)
{
  swap_block = block_get_role (BLOCK_SWAP);
  swap_map = bitmap_create (block_size (swap_block) *
                              BLOCK_SECTOR_SIZE / PGSIZE);
  bitmap_set_all (swap_map, SWAP_FREE);
  lock_init (&swap_lock);
}

bool
swap_in (void* kpage, size_t index)
{
  int i;

  lock_acquire (&swap_lock);
  bitmap_flip (swap_map, index);

  for (i=0; i<PGSIZE/BLOCK_SECTOR_SIZE; i++)
  {
    block_read (swap_block, (index*PGSIZE/BLOCK_SECTOR_SIZE)+i,
                kpage+(i*BLOCK_SECTOR_SIZE));
  }
  lock_release (&swap_lock);
  return true;
}

size_t
swap_out (void* kpage)
{
  int i;
  lock_acquire (&swap_lock);
  size_t index = bitmap_scan_and_flip (swap_map, 0, 1, SWAP_FREE);

  for (i=0; i<PGSIZE/BLOCK_SECTOR_SIZE; i++)
  {
    block_write (swap_block, (index*PGSIZE/BLOCK_SECTOR_SIZE)+i,
                 kpage+(i*BLOCK_SECTOR_SIZE));
  }

  lock_release (&swap_lock);
  return index;
}