#ifndef VM_PAGE_H
#define VM_PAGE_H
#include <stdio.h>
#include <stdbool.h>
#include <hash.h>
#include "filesys/file.h"
#include "userprog/syscall.h"

enum supple_pte_type
{
  EXEC,
  SWAP
};

struct supple_pte
{
  void* upage;
  void* kpage;
  bool loaded;
  enum supple_pte_type type;
  struct hash_elem elem;
  struct fte* fte;  

  // For exec file
  struct file* file;
  off_t ofs;
  uint32_t read_bytes;
  bool writable;
  
  // For swap
  size_t index;
};

void spage_init (struct hash* h);
bool load_page (struct supple_pte* supple_pte);
struct supple_pte* get_supple_pte (void* upage);
bool stack_growth (void* upage);
void release_supple_pte (void* upage, size_t index);
#endif /* vm/page.h */